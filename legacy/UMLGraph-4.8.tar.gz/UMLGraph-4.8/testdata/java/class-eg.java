// $Id: class-eg.java,v 1.1 2005/11/23 22:18:45 dds Exp $

/**
 * @opt nodefillcolor ".13 .9 1"
 * @hidden
 */
class UMLOptions{}

class Person {
	String Name;
}

class Employee extends Person {}

class Client extends Person {}
