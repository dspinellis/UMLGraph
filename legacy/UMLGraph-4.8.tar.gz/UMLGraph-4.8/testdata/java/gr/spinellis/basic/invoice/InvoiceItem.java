package gr.spinellis.basic.invoice;

import gr.spinellis.basic.product.*;

/**
 * @assoc * - 1 Product
 */
public class InvoiceItem {

    public Product product;
    public int quantity;
}
