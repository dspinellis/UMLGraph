package gr.spinellis.context.views;

/**
 * @view
 * @opt hide
 * @opt inferrel
 * @opt inferdep
 * @opt inferdepinpackage
 *  
 * @match context gr.spinellis.context.classes.A
 * @opt !hide
 * @match class gr.spinellis.context.classes.A
 * @opt nodefillcolor lemonchiffon
 */
public class ViewContext {
}


