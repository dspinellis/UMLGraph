package gr.spinellis.subclass.classes;

import java.io.Serializable;

public class Super {}

class SubOne extends Super {}

class SubTwo extends Super {}

class SubOneOne extends SubOne {}

class SubOneTwo extends SubOne {}

class Alone {}