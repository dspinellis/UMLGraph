package gr.spinellis.subclass.views;

/**
 * @view
 *
 * @match class .*
 * @opt hide
 * @match subclass gr.spinellis.subclass.classes.Super
 * @opt !hide
 * @match class gr.spinellis.subclass.classes.Super
 * @opt nodefillcolor lemonchiffon
 */
public class ViewSubclasses {
}


