package gr.spinellis.umlgraph.doclet;

/**
 * Options for UMLGraph class diagram generation
 * @opt operations
 * @opt visibility
 * @hidden
 */
public class UMLOptions {}