/* Automatically generated file */
package gr.spinellis.umlgraph.doclet;
class Version { public static String VERSION = "4.8";}
	