// $Id$
package test;

/**
 * @hidden
 * @opt inferrel
 * @opt inferdep
 */
class UMLOptions{}

public class RunnableRef {
    public int method(Runnable r);
}

