package gr.spinellis.basic.views;

/**
 * @view
 * @opt hide 
 * 
 * @match class gr.spinellis.basic.*
 * @opt !hide
 * 
 * @match class gr.spinellis.basic.*
 * @opt attributes 
 * @opt operations 
 * @opt types
 */
public class ViewAllDetailed {
}
