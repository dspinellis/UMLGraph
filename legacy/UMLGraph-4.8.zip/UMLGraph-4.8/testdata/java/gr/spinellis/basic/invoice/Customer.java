package gr.spinellis.basic.invoice;

public class Customer {
    String name;
}
