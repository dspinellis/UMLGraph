// $Id: ctor.java,v 1.1 2005/11/23 22:18:45 dds Exp $

/**
 * @opt all
 * @hidden
 */
class UMLOptions {}
 
class Junk {
    private int value;
    public Junk(int val){}
}
